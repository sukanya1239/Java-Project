CREATE DATABASE project;
USE project;

create table orders (
    id  int(3) NOT NULL AUTO_INCREMENT,
    order_status varchar(128) NOT NULL,
    order_date datetime NOT NULL,
    PRIMARY KEY (id)
);


create table items (
    id  int(3) NOT NULL AUTO_INCREMENT,
    item_name varchar(128) NOT NULL,
    item_unit_price double NOT NULL,
    item_quantity int(3) NOT NULL ,
    order_id int(3) NOT NULL,
    PRIMARY KEY (id),
    CONSTRAINT fk_orders FOREIGN KEY (order_id)  REFERENCES orders(id)  
);

select * from items;